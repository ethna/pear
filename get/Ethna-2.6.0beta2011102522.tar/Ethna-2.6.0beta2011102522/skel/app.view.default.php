<?php
/**
 *  Index.php
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @version    $Id: 213d11c251104242f9806527d410cf7dad779c54 $
 */

/**
 *  Index view implementation.
 *
 *  @author     {$author}
 *  @access     public
 *  @package    {$project_id}
 */
class {$project_id}_View_Index extends {$project_id}_ViewClass
{
    /**
     *  preprocess before forwarding.
     *
     *  @access public
     */
    public function preforward()
    {
    }
}

