<?php
// vim: foldmethod=marker
/**
 *  {$plugin_name} Smarty function Plugin
 *
 *  @author     your name <yourname@example.com>
 *  @license    http://www.opensource.org/licenses/bsd-license.php The BSD License
 *  @package    Ethna_Plugin
 *  @version    $Id: cb4af5ee423db0250d0f777b1c148277f72202c5 $
 */

function smarty_function_{$plugin_name}($params, &$smarty)
{
}
