<?php
/**
 * {$file_path}
 * 
 * @author    {$author}
 * @package   {$project_id}.Test
 * @version   $Id: 8370e188e120cb5dfc1adaa9594709d2287882c8 $
 */

/**
 * {$name} TestCase 
 * 
 * @author    {$author}
 * @package   {$project_id}.Test
 */
class {$name}_TestCase extends Ethna_UnitTestCase
{
    /**
     * initialize test.
     * 
     * @access public
     */
    function setUp()
    {
        // TODO: write test initialization code.
        // Example: read test data from database.
    }
    
    /**
     *  clean up testcase.
     * 
     *  @access public
     */
    function tearDown()
    {
        // TODO: write testcase cleanup code.
        // Example: restore database data for development.
    }
    
    /**
     * sample testcase.
     * 
     * @access public
     */
    function test_{$name}()
    {
        /**
         *  TODO: write test case! :)
         *  @see http://simpletest.org/en/first_test_tutorial.html
         *  @see http://simpletest.org/en/unit_test_documentation.html
         */
        $this->fail('No Test! write Test!');
    }
}

